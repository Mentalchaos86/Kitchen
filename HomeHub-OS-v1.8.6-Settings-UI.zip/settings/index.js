import { profileSettings } from "./profile.js";
import { appearanceSettings } from "./appearance.js";
import { moduleSettings } from "./modules.js";
import { intelligenceSettings } from "./intelligence.js";
import { systemSettings } from "./system.js";
import { momentSettings } from "./moments.js";
import { modeSettings } from "./modes.js";
import { preparationSettings } from "./preparation.js";
import { predictiveMomentSettings } from "./predictive-moments.js";
import { morningBriefSettings } from "./morning-brief.js";

export const settings = {
  profile: profileSettings,
  appearance: appearanceSettings,
  modules: moduleSettings,
  intelligence: intelligenceSettings,
  system: systemSettings,
  moments: momentSettings,
  modes: modeSettings,
  preparation: preparationSettings,
  predictiveMoments: predictiveMomentSettings,
  morningBrief: morningBriefSettings
};
