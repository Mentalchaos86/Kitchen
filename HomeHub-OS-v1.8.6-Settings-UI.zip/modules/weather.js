import { config } from "../core/config.js";
import { $ } from "../core/dom.js";
import { markUpdated } from "../core/status.js";
import { getIntelligenceContext } from "../core/context.js";

const weatherCodes = {
  0:["Clear","☀️"],1:["Mostly clear","🌤️"],2:["Partly cloudy","⛅"],3:["Cloudy","☁️"],
  45:["Fog","🌫️"],48:["Fog","🌫️"],51:["Light drizzle","🌦️"],53:["Drizzle","🌦️"],
  55:["Heavy drizzle","🌧️"],61:["Light rain","🌦️"],63:["Rain","🌧️"],65:["Heavy rain","🌧️"],
  71:["Light snow","🌨️"],73:["Snow","❄️"],75:["Heavy snow","❄️"],
  80:["Rain showers","🌦️"],81:["Showers","🌧️"],82:["Heavy showers","⛈️"],
  95:["Thunderstorm","⛈️"],96:["Thunderstorm","⛈️"],99:["Thunderstorm","⛈️"]
};

const weatherText = code => weatherCodes[code] || ["Weather","🌡️"];

export async function loadWeather() {
  const intelligentLocation = getIntelligenceContext().weather;
  const weather = intelligentLocation
    ? {
        latitude: intelligentLocation.latitude,
        longitude: intelligentLocation.longitude,
        locationName: intelligentLocation.city,
        timezone: intelligentLocation.timezone
      }
    : config.weather;

  $("weatherLocation").textContent =
    (weather.locationName || "Local").toUpperCase();

  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.search = new URLSearchParams({
    latitude: weather.latitude,
    longitude: weather.longitude,
    current:
      "temperature_2m,apparent_temperature,weather_code,relative_humidity_2m,precipitation,wind_speed_10m",
    daily:
      "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max",
    timezone: weather.timezone || "auto",
    forecast_days: "1"
  });

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("Weather unavailable");

    const data = await response.json();
    const [label, icon] = weatherText(data.current.weather_code);

    const timeFormatter = new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
    });

    $("weatherDetails").innerHTML = `
      <div class="weather-now">
        <div class="weather-now-primary">
          <span class="weather-detail-icon">${icon}</span>
          <div class="weather-current-temp">${Math.round(data.current.temperature_2m)}°</div>
        </div>

        <div class="weather-now-copy">
          <div class="weather-detail-main">${label}</div>
          <div class="weather-detail-sub">
            Feels ${Math.round(data.current.apparent_temperature)}°
          </div>
        </div>

        <div class="weather-now-metrics">
          <span title="Rain chance">🌧 ${Math.round(data.daily.precipitation_probability_max[0] || 0)}%</span>
          <span title="Wind">💨 ${Math.round(data.current.wind_speed_10m)} km/h</span>
        </div>
      </div>`;

    // Today is represented by the large current-weather area above.
    // The compact strip deliberately starts with tomorrow.
    const forecast = $("forecast");
    if (forecast) forecast.innerHTML = "";

    markUpdated();
  } catch (error) {
    $("weatherDetails").innerHTML =
      `<div class="empty-state">Weather unavailable.</div>`;
    $("forecast").innerHTML = "";
    console.error("[Weather]", error);
  }
}

export function initWeather() {
  loadWeather();
  window.addEventListener("homehub:intelligence-change", loadWeather);
  setInterval(
    loadWeather,
    Math.max(5, config.refreshMinutes || 15) * 60000
  );
}
